import 'package:breaking_bad/Data/Models/Character.dart';
import 'package:flutter/material.dart';

class CharacterItem extends StatelessWidget {

  const CharacterItem({super.key, required Character character});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}