import 'package:flutter/material.dart';

class Mycololrs {
  static const Color MyYellow = Color(0xffffc107);
  static const Color MyGry = Color(0xff343a40);
  static const Color MyWhite = Color(0xffe1e8eb);
}
