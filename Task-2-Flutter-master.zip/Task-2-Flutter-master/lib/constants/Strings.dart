const baseUrl = 'https://rickandmortyapi.com/api/';
const characterScreen = '/';
const characterDetailsScreen = '/character_details';
