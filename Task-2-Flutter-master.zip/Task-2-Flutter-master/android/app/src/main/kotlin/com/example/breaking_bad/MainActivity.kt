package com.example.breaking_bad

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
